"""A package that contains models that represent entities.
"""
